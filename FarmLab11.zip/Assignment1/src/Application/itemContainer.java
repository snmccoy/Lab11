package Application;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

// Composite class for farm containers
public class itemContainer implements farmItem {

    private final String name;
    private final double price;
    private final double x;
    private final double y;
    private final double width;
    private final double height;

    private final List<farmItem> contents = new ArrayList<>();

    public itemContainer(String name, double price,
                         double x, double y,
                         double width, double height) {

        this.name = name;
        this.price = price;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public void add(farmItem child) {
        contents.add(child);
    }

    @Override
    public void remove(farmItem child) {
        contents.remove(child);
    }

    @Override
    public double getPrice() {
        double total = price;

        for (farmItem child : contents) {
            total += child.getPrice();
        }

        return total;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(String indent) {
        System.out.println(
            indent + name + " (total $" + getPrice() + ")"
        );

        for (farmItem child : contents) {
            child.display(indent + "    ");
        }
    }

    @Override
    public double getX() {
        return x;
    }

    @Override
    public double getY() {
        return y;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public void draw(Pane pane) {

        Rectangle rectangle =
            new Rectangle(x, y, width, height);

        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.SADDLEBROWN);
        rectangle.setStrokeWidth(2);

        Text label =
            new Text(x + 6, y + 16, name);

        // Draw container before its children
        pane.getChildren().addAll(rectangle, label);

        // Draw all children recursively
        for (farmItem child : contents) {
            child.draw(pane);
        }
    }

    @Override
    public void collect(List<farmItem> out) {

        // Add this container first
        out.add(this);

        // Then collect all children
        for (farmItem child : contents) {
            child.collect(out);
        }
    }

    @Override
    public String toString() {
        return name;
    }
}