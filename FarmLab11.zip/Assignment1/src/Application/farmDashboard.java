package Application;

import javafx.animation.Animation;
import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;

public class farmDashboard extends Application {

    private Circle droneCircle;
    private double homeX;
    private double homeY;
    private SequentialTransition currentFlight;

    @Override
    public void start(Stage stage) {

        // Create all farm objects
        itemContainer farm = new itemContainer(
            "Farm", 0, 0, 0, 800, 600);

        itemContainer barn = new itemContainer(
            "Barn", 20000, 20, 40, 360, 300);

        itemContainer livestock = new itemContainer(
            "Livestock Area", 3000, 40, 70, 200, 140);

        item cow = new item(
            "Cow", 1500, 70, 120, 50, 30);

        item milkStorage = new item(
            "Milk Storage", 4000, 260, 70, 100, 60);

        itemContainer storage = new itemContainer(
            "Storage Building", 8000, 420, 40, 360, 160);

        item tractor = new item(
            "Tractor", 45000, 450, 90, 100, 50);

        item tiller = new item(
            "Tiller", 2500, 600, 90, 80, 50);

        itemContainer commandCenter = new itemContainer(
            "Command Center", 10000, 20, 380, 260, 180);

        item droneItem = new item(
            "Drone", 1200, 120, 440, 60, 60);

        item soyCrop = new item(
            "Soy Crop", 6000, 420, 240, 360, 320);

        // Build the Composite tree
        farm.add(barn);

        barn.add(livestock);
        livestock.add(cow);
        barn.add(milkStorage);

        farm.add(storage);
        storage.add(tractor);
        storage.add(tiller);

        farm.add(commandCenter);
        commandCenter.add(droneItem);

        farm.add(soyCrop);

        // Draw the entire farm with one call
        Pane farmPane = new Pane();
        farmPane.setPrefSize(800, 600);
        farmPane.setMinSize(800, 600);
        farmPane.setMaxSize(800, 600);

        farm.draw(farmPane);

        // Collect all objects from the tree
        List<farmItem> allItems = new ArrayList<>();
        farm.collect(allItems);

        System.out.println(
            "Items and containers on the farm: "
            + allItems.size()
        );

        // Drone starting position
        homeX = droneItem.getX()
              + droneItem.getWidth() / 2;

        homeY = droneItem.getY()
              + droneItem.getHeight() / 2;

        droneCircle = new Circle(homeX, homeY, 12);
        droneCircle.setFill(Color.DODGERBLUE);

        farmPane.getChildren().add(droneCircle);

        // Dropdown and buttons
        ComboBox<farmItem> itemCombo = new ComboBox<>();
        itemCombo.getItems().addAll(allItems);
        itemCombo.setPrefWidth(200);
        itemCombo.getSelectionModel().select(cow);

        Button visitButton =
            new Button("Visit Item/Container");

        Button scanButton =
            new Button("Scan Farm");

        visitButton.setOnAction(e -> {
            farmItem selected = itemCombo.getValue();

            if (selected != null && !isFlying()) {
                visitItem(selected);
            }
        });

        scanButton.setOnAction(e -> {
            if (!isFlying()) {
                scanFarm(allItems);
            }
        });

        HBox controls = new HBox(
            10, itemCombo, visitButton, scanButton);

        controls.setAlignment(Pos.CENTER);
        controls.setStyle("-fx-padding: 10;");

        BorderPane root = new BorderPane();
        root.setCenter(farmPane);
        root.setBottom(controls);

        Scene scene = new Scene(root, 800, 650);

        stage.setTitle("Farm Monitoring Dashboard");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    // Prevent overlapping animations
    private boolean isFlying() {
        return currentFlight != null
            && currentFlight.getStatus()
                == Animation.Status.RUNNING;
    }

    // Fly to the center of a target
    private TranslateTransition createFlight(
            farmItem target) {

        double targetX =
            target.getX() + target.getWidth() / 2;

        double targetY =
            target.getY() + target.getHeight() / 2;

        TranslateTransition flight =
            new TranslateTransition(
                Duration.seconds(0.8),
                droneCircle
            );

        flight.setToX(targetX - homeX);
        flight.setToY(targetY - homeY);

        flight.setOnFinished(e ->
            System.out.println(
                "Drone reached: " + target.getName()
            )
        );

        return flight;
    }

    // Fly back to the Command Center
    private TranslateTransition createReturnFlight() {

        TranslateTransition home =
            new TranslateTransition(
                Duration.seconds(0.8),
                droneCircle
            );

        home.setToX(0);
        home.setToY(0);

        home.setOnFinished(e ->
            System.out.println(
                "Drone back at Command Center"
            )
        );

        return home;
    }

    // Task 3: Visit one selected object
    private void visitItem(farmItem target) {

        TranslateTransition outgoing =
            createFlight(target);

        TranslateTransition returning =
            createReturnFlight();

        currentFlight = new SequentialTransition(
            outgoing, returning
        );

        currentFlight.play();
    }

    // Task 4 Bonus: Scan all objects except Farm
    private void scanFarm(List<farmItem> allItems) {

        currentFlight = new SequentialTransition();

        for (int i = 1; i < allItems.size(); i++) {
            currentFlight.getChildren().add(
                createFlight(allItems.get(i))
            );
        }

        currentFlight.getChildren().add(
            createReturnFlight()
        );

        currentFlight.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}