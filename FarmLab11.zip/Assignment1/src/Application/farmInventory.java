package Application;

import java.util.ArrayList;
import java.util.List;

// Task 1: Component
interface FarmItem {
    // add and remove belong here so clients can treat all farm objects
    // uniformly, even though leaf objects cannot contain other items.
    void add(FarmItem item);
    void remove(FarmItem item);
    double getPrice();
    String getName();
    void display(String indent); 
}

// Task 2: Leaf
class Cow implements FarmItem {
    private final String name;
    private final double price;

    public Cow(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public void add(FarmItem item) {
        throw new UnsupportedOperationException(
            "Cannot add an item to a cow.");
    }

    @Override
    public void remove(FarmItem item) {
        throw new UnsupportedOperationException(
            "Cannot remove an item from a cow.");
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(String indent) {
        System.out.println(indent + name + " $" + getPrice());
    }
}

// Task 2: Leaf
class Tractor implements FarmItem {
    private final String name;
    private final double price;

    public Tractor(String name, double price) {
        this.name = name;
        this.price = price;  
    }

    @Override
    public void add(FarmItem item) {
        throw new UnsupportedOperationException(
            "Cannot add an item to a tractor.");
    }

    @Override
    public void remove(FarmItem item) {
        throw new UnsupportedOperationException(
            "Cannot remove an item from a tractor.");
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getName() {
        return name;
    } 

    @Override
    public void display(String indent) {
        System.out.println(indent + name + " $" + getPrice());
    }
}

// Task 3: Composite
class Barn implements FarmItem {
    private final String name;
    private final double price;
    private final List<FarmItem> contents = new ArrayList<>();

    public Barn(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public void add(FarmItem item) {
        contents.add(item);
    }

    @Override
    public void remove(FarmItem item) {
        contents.remove(item);
    }

    @Override
    public double getPrice() {
        double total = price;

        for (FarmItem item : contents) {
            total += item.getPrice();
        }

        return total;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(String indent) {
        System.out.println(
            indent + name + " (total $" + getPrice() + ")");

        for (FarmItem item : contents) {
            item.display(indent + "    ");
        }
    }
}

// Task 3: Composite
class StorageBuilding implements FarmItem {
    private final String name; 
    private final double price;
    private final List<FarmItem> contents = new ArrayList<>();

    public StorageBuilding(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public void add(FarmItem item) {
        contents.add(item);
    }

    @Override
    public void remove(FarmItem item) {
        contents.remove(item);
    }

    @Override
    public double getPrice() {
        double total = price;

        for (FarmItem item : contents) {
            total += item.getPrice();
        }

        return total;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(String indent) {
        System.out.println(
            indent + name + " (total $" + getPrice() + ")");

        for (FarmItem item : contents) {
            item.display(indent + "    "); 
        }
    }
}

// Task 4
public class farmInventory {
    public static void main(String[] args) {
        FarmItem farm = new Barn("Farm", 0.0);
        FarmItem redBarn = new Barn("Red Barn", 20000.0);
        FarmItem milkingRoom = new Barn("Milking Room", 5000.0);
        FarmItem storage = new StorageBuilding(
            "Storage Building", 8000.0);

        FarmItem bessie = new Cow("Bessie", 1500.0);
        FarmItem daisy = new Cow("Daisy", 1200.0);
        FarmItem clover = new Cow("Clover", 1300.0);
        FarmItem tractor = new Tractor(
            "John Deere 5075E", 45000.0);

        //the Milking Room
        milkingRoom.add(bessie);
        milkingRoom.add(daisy);

        // The Red Barn
        redBarn.add(milkingRoom);
        redBarn.add(clover); 

        // The Storage Building
        storage.add(tractor);

        // Build the Farm
        farm.add(redBarn);
        farm.add(storage); 
        
        farm.display("");
        System.out.println(
            "Total farm value: $" + farm.getPrice());

        milkingRoom.remove(daisy);
        System.out.println("After selling Daisy:");
        System.out.println(
            "Total farm value: $" + farm.getPrice());
    }
}
