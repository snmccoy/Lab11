package Application;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import java.util.List;

// Leaf class for individual farm items
public class item implements farmItem {

    private final String name;
    private final double price;
    private final double x;
    private final double y;
    private final double width;
    private final double height;

    public item(String name, double price,
                double x, double y,
                double width, double height) {

        this.name = name;
        this.price = price;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public void add(farmItem item) {
        throw new UnsupportedOperationException(
            "Cannot add an item to a leaf.");
    }

    @Override
    public void remove(farmItem item) {
        throw new UnsupportedOperationException(
            "Cannot remove an item from a leaf.");
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(String indent) {
        System.out.println(
            indent + name + " $" + getPrice());
    }

    @Override
    public double getX() {
        return x;
    }

    @Override
    public double getY() {
        return y;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public void draw(Pane pane) {

        Rectangle rectangle =
            new Rectangle(x, y, width, height);

        rectangle.setFill(Color.LIGHTGREEN);
        rectangle.setStroke(Color.DARKGREEN);

        Text label =
            new Text(x + 4, y + 14, name);

        pane.getChildren().addAll(
            rectangle, label);
    }

    @Override
    public void collect(List<farmItem> out) {
        out.add(this);
    }

    @Override
    public String toString() {
        return name;
    }
}