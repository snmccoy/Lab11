package Application;

import javafx.scene.layout.Pane;
import java.util.List;

public interface farmItem {

    void add(farmItem item);
    void remove(farmItem item);

    double getPrice();
    String getName();

    void display(String indent);

    double getX();
    double getY();
    double getWidth();
    double getHeight();

    void draw(Pane pane);
    void collect(List<farmItem> out);
}